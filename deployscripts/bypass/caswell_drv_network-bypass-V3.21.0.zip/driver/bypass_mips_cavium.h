/*
  * We define the platform dependence config here
  */
#include "bypass_def.h"
#include "bypass_platform_type.h"
#include "bypass_pciwdt.h"
#include "bypass_add-on.h"

//Type list of ca board bypass
#define BP_MB_MAX		4
#define BP_MB_MEB3920	0
#define BP_MB_MEB3930	1
#define BP_MB_CAPK0100	2
#define BP_MB_CAPK3000	3

#ifndef  __INCLUDE_PLATEFORM_DATA__

unsigned char *BP_MB_NAME[BP_MB_MAX]={"MEB392X", "MEB393X", "CAPK0100ND", "CAPK3000NR"};

bp_unit mb_bypass_info[BP_MB_MAX]={
	//{ board index, bypass type, total segs, ctrl addr, wdt addr, period addr, 9559 addr, generation }
	/*set MEB3920 motherboard configuration*/
	{BP_MB_MEB3920, BP_COPPER_PIC, BP_SEGS_2,\
	{0x25, 0x25}, {0x0,0x0}, {0x0,0x0}, {0x0,0x0}, 0, BP_GEN2, NULL},

	/*set MEB3930 motherboard configuration*/
	{BP_MB_MEB3930, BP_COPPER_CPLDV2, BP_SEGS_1,\
	{0x26}, {0x0}, {0x0}, {0x4f}, 0, BP_GEN2, NULL},

	/*set CAPK-0100ND motherboard configuration*/
	{BP_MB_CAPK0100, BP_COPPER_CPLDV2, BP_SEGS_1,\
	{0x26}, {0x0}, {0x0}, {0x0}, BP_GEN1},

	/*set CAPK-3000NR motherboard configuration*/
	{BP_MB_CAPK3000, BP_COPPER_CPLDV2, BP_SEGS_2,\
	{0x26, 0x22}, {0x0, 0x0}, {0x26, 0x26}, {0x4f, 0x4f}, 0, BP_GEN2, NULL}
};

#endif  /*__INCLUDE_PLATEFORM_DATA__*/
