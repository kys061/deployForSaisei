/*******************************************************************************

  CASwell(R) Gen3 Bypass Linux driver
  Copyright(c) 2011 Zeno Lai <zeno.lai@cas-well.com>

  This program is free software; you can redistribute it and/or modify it
  under the terms and conditions of the GNU General Public License,
  version 2, as published by the Free Software Foundation.

  This program is distributed in the hope it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
  more details.

  You should have received a copy of the GNU General Public License along with
  this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.

*******************************************************************************/

#ifndef _NUVOTON_DEFINES_H_
#define _NUVOTON_DEFINES_H_

/***********************
 *  Registers          *
 ***********************/

/* Gen3.3 : SPI Interface */
#define SIO_SK_REG_0		0 //SIO_GP00, spi_clk
#define SIO_SS_REG_0		3 //SIO_GP03, spi_ss
#define SIO_MOSI_REG_0		1 //SIO_GP01, spi_mosi
#define SIO_MISO_REG_0		2 //SIO_GP02, spi_miso
#define SIO_BUSY_REG_0		4 //SIO_GP04, spi_mcu_busy

#define SIO_SK_REG_1		34 //SIO_GP34, spi_clk
#define SIO_SS_REG_1		41 //SIO_GP41, spi_ss
#define SIO_MOSI_REG_1		35 //SIO_GP35, spi_mosi
#define SIO_MISO_REG_1		36 //SIO_GP36, spi_miso
#define SIO_BUSY_REG_1		24 //SIO_GP24, spi_mcu_busy

/* Gen3.3 : The thied bypass GPIO */
#define SIO_SK_REG_2		5  //SIO_GP05, spi_clk
#define SIO_SS_REG_2		45 //SIO_GP45, spi_ss
#define SIO_MOSI_REG_2		6  //SIO_GP06, spi_mosi
#define SIO_MISO_REG_2		7  //SIO_GP07, spi_miso
#define SIO_BUSY_REG_2		46 //SIO_GP046, spi_mcu_busy

/* Gen3.4 : SPI Interface */
#define SIO_SK_REG          0 //SIO_GP00, spi_clk
#define SIO_SS_REG          3 //SIO_GP03, spi_ss
#define SIO_MOSI_REG        1 //SIO_GP01, spi_mosi
#define SIO_MISO_REG        2 //SIO_GP02, spi_miso
#define SIO_BUSY_REG        4 //SIO_GP04, spi_mcu_busy

/* BP segment 1 = 0:[000] */
/* BP segment 2 = 1:[001] */
/* BP segment 3 = 2:[010] */
#define SIO_MUX_ADDR_0      34 // BP segment addr bit0
#define SIO_MUX_ADDR_1      35 // BP segment addr bit1
#define SIO_MUX_ADDR_2      36 // BP segment addr bit2

// Mask
#define SIO_GPIO_HIGH            0x01
#define SIO_GPIO_LOW             0x00


#endif
