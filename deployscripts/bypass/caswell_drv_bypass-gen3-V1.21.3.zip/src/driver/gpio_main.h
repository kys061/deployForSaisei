
/*******************************************************************************

  CASwell(R) Nuvoton Super I/O GPIO Linux driver
  Copyright(c) 2013 Alan Yu     <alan.yu@cas-well.com>

  This program is free software; you can redistribute it and/or modify it
  under the terms and conditions of the GNU General Public License,
  version 2, as published by the Free Software Foundation.

  This program is distributed in the hope it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
  more details.

  You should have received a copy of the GNU General Public License along with
  this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.

*******************************************************************************/

#ifndef _GPIO_MAIN_H_
#define _GPIO_MAIN_H_

#define EFER                    0x2E
#define EFIR                    0x2E
#define EFDR                    0x2F

#define CR7                     0x07
#define LD7                     0x07
#define LD8                     0x08
#define LD9                     0x09

#define GPIO_USE_SEL            0x30

#define GP_IO                   0
#define GP_LVL                  1
#define GPI_INV                 2

#define SELECT_OPT              0
#define OUTPUT_OPT              1
#define INPUT_OPT               2
#define DIRECTION_OPT           3
#define INVERSE_OPT             4

#define BIT_HI                  1
#define BIT_LO                  0
#define MAX_GPIO_PINS           8
#define MAX_MFUNC_REGS          2

#define NCT6779D      0xC5
#define NCT6796D      0xD4

/* Nuvoton gpio */
struct nuvoton_gpio {
	void (*set_select)(int, int);
        void (*set_direction)(int, int);
	void (*set_output)(int, int);

	u8 (*get_select)(int);
        u8 (*get_direction)(int);
        u8 (*get_output)(int);
};

struct SIO_DEVICE {
        u32 devid;
        u8 *devname;
        u8 ports;
};

#define SIO_PRIV(id, name, pt)  \
        .devid = id,                \
        .devname = name,        \
        .ports = pt

void nuvoton_enter_ext_mode(void);
void nuvoton_leave_ext_mode(void);
void nuvoton_access_device(u8 ld);
u8 nuvoton_get_devid(void);
int nuvoton_match(void);

#endif /* _GPIO_MAIN_H_ */
