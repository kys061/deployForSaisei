
/*******************************************************************************

  CASwell(R) Nuvoton Super I/O GPIO Linux driver
  Copyright(c) 2013 Alan Yu     <alan.yu@cas-well.com>

  This program is free software; you can redistribute it and/or modify it
  under the terms and conditions of the GNU General Public License,
  version 2, as published by the Free Software Foundation.

  This program is distributed in the hope it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
  more details.

  You should have received a copy of the GNU General Public License along with
  this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.

*******************************************************************************/

#ifndef _NCT6796D_H_
#define _NCT6796D_H_

#define NCT6796D_GPIO0		0xE0
#define NCT6796D_GPIO1		0xF0
#define NCT6796D_GPIO2		0xE0
#define NCT6796D_GPIO3		0xE4
#define NCT6796D_GPIO4		0xF0
#define NCT6796D_GPIO5		0xF4
#define NCT6796D_GPIO6		0xF4
#define NCT6796D_GPIO7		0xE0
#define NCT6796D_GPIO8		0xE4

void nct6796d_set_gpio_use_sel(int cmd, int pin);
void nct6796d_set_gp_io_sel(int cmd, int pin);
void nct6796d_set_gp_lvl(int cmd, int pin);
void nct6796d_set_gpi_inv(int cmd, int pin);
u8 nct6796d_get_gpio_use_sel(int port);
u8 nct6796d_get_gp_io_sel(int port);
u8 nct6796d_get_gp_lvl(int port);
u8 nct6796d_get_gpi_inv(int port);
#endif /* _NCT6796D_H_ */
