/*******************************************************************************

  CASwell(R) Nuvoton Super I/O GPIO Linux driver
  Copyright(c) 2013 Alan Yu     <alan.yu@cas-well.com>

  This program is free software; you can redistribute it and/or modify it
  under the terms and conditions of the GNU General Public License,
  version 2, as published by the Free Software Foundation.

  This program is distributed in the hope it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
  more details.

  You should have received a copy of the GNU General Public License along with
  this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.

*******************************************************************************/

#include <linux/module.h>
#include <linux/init.h>
#include <linux/version.h>
#include <linux/types.h>
#include <linux/fs.h>
#include <linux/string.h>
#include <linux/pci.h>

#include "gpio_main.h"
#include "nct6779d.h"
#include "nct6796d.h"

static struct SIO_DEVICE sio_device_tbl [] = {
        { SIO_PRIV(0xC5, "NCT6779D", 9) },
        { SIO_PRIV(0xD4, "NCT6796D", 9) },
        { 0 },
};

void nuvoton_enter_ext_mode(void)
{
        outb(0x87, EFER);
        outb(0x87, EFER);
}

void nuvoton_leave_ext_mode(void)
{
        outb(0xAA, EFER);
}

void nuvoton_access_device(u8 ld)
{
        outb(CR7, EFIR);
        outb(ld, EFDR);
}

u8 nuvoton_get_devid(void)
{
        u8 val;

        nuvoton_enter_ext_mode();
        outb(0x20, EFER);
        val = inb(EFDR);
        nuvoton_leave_ext_mode();

        return val;
}

int nuvoton_match(void)
{
        u8 val;
        int i;

        val = nuvoton_get_devid();

        for (i = 0; i < sizeof(sio_device_tbl)/sizeof(struct SIO_DEVICE); i++) {
                if (val == sio_device_tbl[i].devid) {
                        return val;
                }
        }

        return -1;
}

