NIAGARA_DRIVER_ATTRIBUTE(version, 0444)
NIAGARA_DRIVER_ATTRIBUTE(maxcard, 0444)
// supported_cards is placed as a file, but it's not attribute
